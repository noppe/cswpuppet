---
layout: default
title: EC2 Demo
toc: false
---


The EC2 MCollective demo has been deprecated in favor of a better Vagrant-based demo.

* [About the Vagrant demo](/mcollective/deploy/demo.html)
* [Download the Vagrant demo](https://github.com/ripienaar/mcollective-vagrant)
