test_name "Validate Sign Cert"

require 'puppet/acceptance/common_utils'
extend Puppet::Acceptance::CAUtils

initialize_ssl
