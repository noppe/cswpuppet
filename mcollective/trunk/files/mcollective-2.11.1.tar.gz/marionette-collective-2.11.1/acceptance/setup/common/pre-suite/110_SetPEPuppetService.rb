master['puppetservice'] = 'pe-puppetserver'
