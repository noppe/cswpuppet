module MCollective
  class Application::Test < Application
    def run
      true
    end
  end
end
