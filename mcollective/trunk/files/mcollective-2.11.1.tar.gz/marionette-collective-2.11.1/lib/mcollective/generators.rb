module MCollective
  module Generators
    require "mcollective/generators/base.rb"
    require "mcollective/generators/data_generator.rb"
    require "mcollective/generators/agent_generator.rb"
  end
end
